create definer = root@localhost trigger check_end_date_before_insert_update
    before insert
    on Booking_detail
    for each row
begin
    if new.end_date <= new.start_date then
        signal sqlstate '45000'
            set message_text = 'Ngày kết thúc phải lớn hơn ngày bắt đầu';
    end if;
end;

