create
    definer = root@localhost procedure addRoominfo(IN p_name varchar(150), IN p_status tinyint, IN p_price float,
                                                   IN p_category_id int)
begin
    insert into Room (name, status, price, category_id)
    values (p_name, p_status, p_price, p_category_id);
end;

