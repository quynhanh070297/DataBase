create definer = root@localhost view v_getroominfo as
select `qlks2`.`room`.`id`          AS `id`,
       `qlks2`.`room`.`name`        AS `name`,
       `qlks2`.`room`.`status`      AS `status`,
       `qlks2`.`room`.`price`       AS `price`,
       `qlks2`.`room`.`sale_price`  AS `sale_price`,
       `qlks2`.`room`.`create_date` AS `create_date`,
       `qlks2`.`room`.`category_id` AS `category_id`
from `qlks2`.`room`
order by `qlks2`.`room`.`price` desc
limit 10;

