create definer = root@localhost trigger tr_check_Room_NotAllow
    before insert
    on Booking_detail
    for each row
begin
    if
        (NEW.start_date >= any (select d.start_date  from Booking_detail d join Room R on d.room_id = R.id where NEW.room_id = d.room_id) and
       NEW.start_date <= any (select d.end_date  from Booking_detail d join Room R on d.room_id = R.id where NEW.room_id = d.room_id))or
     (  NEW.end_date <= any (select d.end_date from Booking_detail d join Room R on d.room_id = R.id where NEW.room_id = d.room_id) and
       NEW.end_date >= any (select d.start_date from Booking_detail d join Room R on d.room_id = R.id where NEW.room_id = d.room_id) )
    then signal sqlstate  '45000'set message_text = 'Toang roi cu';
    end if;
end;

