create
    definer = root@localhost procedure getBookingByCustomerId(IN p_customer_id int)
begin
    select B.id as Id,
           B.bookingdate as BookingDate,
           CasE
               when B.status = 0 then 'Chưa duyệt'
               when B.status = 1 then 'Đã duyệt'
               when B.status = 2 then 'Đã thanh toán'
               when B.status = 3 then 'Đã hủy'
               ELSE 'Trạng thái không xác định'
               end as Status,
           SUM(BD.price) as TotalAmount
    from Booking B
             join Booking_detail BD on B.id = BD.Booking_id
    where B.customer_Id = p_customer_id
    group by B.id;
end;

