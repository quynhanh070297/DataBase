create definer = root@localhost view v_getbookinglist as
select `B`.`id`                                                                                           AS `Id`,
       `B`.`bookingdate`                                                                                  AS `BookingDate`,
       (case
            when (`B`.`status` = 0) then 'Chưa duyệt'
            when (`B`.`status` = 1) then 'Đã duyệt'
            when (`B`.`status` = 2) then 'Đã thanh toán'
            when (`B`.`status` = 3) then 'Đã hủy'
            else 'Trạng thái không xác định' end)                                                         AS `Status`,
       `C`.`name`                                                                                         AS `CusName`,
       `C`.`email`                                                                                        AS `Email`,
       `C`.`phone`                                                                                        AS `Phone`,
       (select sum(`BD`.`price`)
        from `qlks2`.`booking_detail` `BD`
        where (`BD`.`Booking_id` = `B`.`id`))                                                             AS `TotalAmount`
from (`qlks2`.`booking` `B` join `qlks2`.`customer` `C` on ((`B`.`customer_Id` = `C`.`id`)));

