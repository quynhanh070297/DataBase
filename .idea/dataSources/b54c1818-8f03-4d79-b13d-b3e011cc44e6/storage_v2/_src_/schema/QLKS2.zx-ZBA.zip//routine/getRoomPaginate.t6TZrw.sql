create
    definer = root@localhost procedure getRoomPaginate(IN p_limit int, IN p_page int)
begin
    declare offset_val int default 0;
    set offset_val = (p_page - 1) * p_limit;

    select id, name, price, sale_price
    from Room
    order by id
    limit p_limit OFFset offset_val;
end;

