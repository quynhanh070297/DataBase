create definer = root@localhost trigger auto_sale_set
    before insert
    on Room
    for each row
begin
    if NEW.sale_price > NEW.price
    then
        signal sqlstate '45000' set message_text = 'loi tum lum';
    end if;
end;

