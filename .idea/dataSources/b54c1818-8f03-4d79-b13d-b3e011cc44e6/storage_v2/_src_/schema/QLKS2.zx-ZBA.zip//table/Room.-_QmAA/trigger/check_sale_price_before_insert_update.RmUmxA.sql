create definer = root@localhost trigger check_sale_price_before_insert_update
    before insert
    on Room
    for each row
begin
    if new.sale_price > new.price then
        signal sqlstate '45000'
            set message_text = 'Giá sale_price không được lớn hơn giá price';
    end if;
end;

